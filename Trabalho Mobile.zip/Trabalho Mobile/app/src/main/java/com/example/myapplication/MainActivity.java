package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private Button btEnviar;
    private Button btLimpar;
    private EditText ETNome;
    private EditText ETEmail;
    private EditText ETIdade;
    private EditText ETDisciplina;
    private EditText ETNota1;
    private EditText ETNota2;
    private TextView TVNome;
    private TextView TVEmail;
    private TextView TVIdade;
    private TextView TVDisciplina;
    private TextView TVNota1Nota2;
    private TextView TVMedia;
    private TextView TVAprovadoeReprovado;
    private TextView TVErro1;
    private TextView TVErro2;
    private TextView TVErro3;
    private TextView TVErro4;
    private TextView TVErro5;
    private TextView TVErro6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btEnviar = findViewById(R.id.btEnviar);
        btLimpar = findViewById(R.id.btLimpar);
        ETNome = findViewById(R.id.ETNome);
        ETEmail = findViewById(R.id.ETEmail);
        ETIdade = findViewById(R.id.ETIdade);
        ETDisciplina = findViewById(R.id.ETDisciplina);
        ETNota1 = findViewById(R.id.ETNota1);
        ETNota2 = findViewById(R.id.ETNota2);
        TVNome = findViewById(R.id.TVNome);
        TVEmail = findViewById(R.id.TVEmail);
        TVIdade = findViewById(R.id.TVIdade);
        TVDisciplina = findViewById(R.id.TVDisciplina);
        TVNota1Nota2 = findViewById(R.id.TVNota1Nota2);
        TVMedia = findViewById(R.id.TVMedia);
        TVAprovadoeReprovado = findViewById(R.id.TVAprovadoeReprovado);
        TVErro1 = findViewById(R.id.TVErro1);
        TVErro2 = findViewById(R.id.TVErro2);
        TVErro3 = findViewById(R.id.TVErro3);
        TVErro4 = findViewById(R.id.TVErro4);
        TVErro5 = findViewById(R.id.TVErro5);
        TVErro6 = findViewById(R.id.TVErro6);

        btEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Enviar();
            }
        });

        btLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Limpar();
            }
        });
    }

    private void Enviar() {
        String nome = ETNome.getText().toString();
        String email = ETEmail.getText().toString();
        String disciplina = ETDisciplina.getText().toString();
        String idadeStr = ETIdade.getText().toString();
        String nota1Str = ETNota1.getText().toString();
        String nota2Str = ETNota2.getText().toString();

        // Validações
        if (nome.isEmpty()) {
            TVErro1.setText("O campo de nome está vazio");
        } else if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            TVErro2.setText("O email é inválido");
        } else if (disciplina.isEmpty()) {
            TVErro3.setText("Disciplina incorreta");
        } else if (idadeStr.isEmpty()) {
            TVErro4.setText("A idade deve ser um número positivo");
        } else {
            int idade;
            double nota1, nota2;

            try {
                idade = Integer.parseInt(idadeStr);
                TVNome.setText("Nome: " + nome);
                TVEmail.setText("Email: " + email);
                TVIdade.setText("Idade: " + idade);
                TVDisciplina.setText("Disciplina: " + disciplina);

                // Validação e cálculo das notas
                if (nota1Str.isEmpty()) {
                    TVErro5.setText("Nota 1 incorreta");
                } else if (nota2Str.isEmpty()) {
                    TVErro6.setText("Nota 2 incorreta");
                } else {
                    try {
                        nota1 = Double.parseDouble(nota1Str);
                        nota2 = Double.parseDouble(nota2Str);

                        if (nota1 < 0 || nota1 > 10) {
                            TVErro5.setText("A nota 1 deve ser de 0 a 10");
                        } else if (nota2 < 0 || nota2 > 10) {
                            TVErro6.setText("A nota 2 deve ser de 0 a 10");
                        } else {
                            TVNota1Nota2.setText("As notas foram 1° BI: " + nota1 + " e 2° BI: " + nota2);
                            double media = (nota1 + nota2) / 2;
                            TVMedia.setText("Média da nota: " + media);

                            if (media < 6) {
                                TVAprovadoeReprovado.setText("Você foi Reprovado!!!");
                            } else {
                                TVAprovadoeReprovado.setText("Você foi Aprovado!!!");
                            }
                        }
                    } catch (NumberFormatException e) {
                        TVErro5.setText("Nota 1 ou Nota 2 inválida");
                    }
                }
            } catch (NumberFormatException e) {
                TVErro4.setText("Idade deve ser um número válido");
            }
        }
    }

    private void Limpar() {
        ETNome.setText("");
        ETEmail.setText("");
        ETIdade.setText("");
        ETDisciplina.setText("");
        ETNota1.setText("");
        ETNota2.setText("");
        TVNome.setText("");
        TVEmail.setText("");
        TVIdade.setText("");
        TVDisciplina.setText("");
        TVNota1Nota2.setText("");
        TVMedia.setText("");
        TVAprovadoeReprovado.setText("");
        TVErro1.setText("");
        TVErro2.setText("");
        TVErro3.setText("");
        TVErro4.setText("");
        TVErro5.setText("");
        TVErro6.setText("");
    }
}